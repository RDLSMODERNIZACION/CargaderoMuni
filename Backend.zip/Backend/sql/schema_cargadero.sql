-- Esquema base resumido (ver mensaje del chat para el script completo)
create extension if not exists pgcrypto with schema public;
